import React from 'react'
import './Pumpsales.css';


export default function Pumpsales() {
  return (
    <div>
        <h2>sai</h2>
      
    </div>
  )
}
