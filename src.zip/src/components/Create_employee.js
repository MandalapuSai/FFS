import React from 'react'
import './Create_employee.css';
// import Sidebar from '../Sidebar';

export default function Create_employee() {
  return (
    <div>
      <h2>Gopi</h2>
      
    </div>
  )
}
