import React from 'react'
import './Attendence.css';

export default function Attendence() {
  return (
    <div>
      Attendence
    </div>
  )
}
