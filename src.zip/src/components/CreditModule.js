import React from 'react'
import './CreditModule.css';

export default function CreditModule() {
  return (
    <div>
        CreditModule
      
    </div>
  )
}
